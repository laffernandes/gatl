/*
 * Copyright (C) 2009 Leandro Augusto Frata Fernandes
 *
 * author   : Fernandes, Leandro A. F.
 * e-mail   : laffernandes@gmail.com
 * home page: http://www.inf.ufrgs.br/~laffernandes
 *
 * version  : Alpha 3.141592
 */

#include <cstdlib>

#include "ga4e.h"
using namespace ga4e;

// Main function.
int
main(int argc, char *argv[])
{
	return EXIT_SUCCESS;
}
