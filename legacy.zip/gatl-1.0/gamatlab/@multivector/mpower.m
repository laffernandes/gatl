function [r] = mpower(varargin)

r = op(varargin{:});