function [r] = times(varargin)

r = gp(varargin{:});