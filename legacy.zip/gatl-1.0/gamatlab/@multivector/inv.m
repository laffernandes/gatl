function [r] = inv(varargin)

r = inverse(varargin{:});