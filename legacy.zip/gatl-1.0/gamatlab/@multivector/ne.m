function [r] = ne(varargin)

r = ~eq(varargin{:});