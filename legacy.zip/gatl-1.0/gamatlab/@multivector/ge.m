function [r] = ge(m1,m2)

check_binary_operation_argin

r = ge(double(m1),double(m2));