function [r] = mtimes(varargin)

r = gp(varargin{:});