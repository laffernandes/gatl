function [r] = mrdivide(varargin)

r = igp(varargin{:});