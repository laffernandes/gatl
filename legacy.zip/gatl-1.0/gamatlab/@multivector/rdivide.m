function [r] = rdivide(varargin)

r = igp(varargin{:});