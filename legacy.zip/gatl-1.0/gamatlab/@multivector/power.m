function [r] = power(varargin)

r = op(varargin{:});