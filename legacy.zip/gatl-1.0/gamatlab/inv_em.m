function [r] = inv_em(varargin)

r = inverse_em(varargin{:});