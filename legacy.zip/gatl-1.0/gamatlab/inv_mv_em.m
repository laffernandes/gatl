function [r] = inv_mv_em(varargin)

r = inverse_mv_em(varargin{:});