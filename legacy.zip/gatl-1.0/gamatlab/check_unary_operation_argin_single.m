if ~isscalar(m)
    error('GAToolbox:InputArgumentsCheck','The input argument must be a single multivector object or a single real scalar value.')
end