function [r] = inv_mv(varargin)

r = inverse_mv(varargin{:});